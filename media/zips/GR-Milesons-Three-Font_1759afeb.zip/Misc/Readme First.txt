Thanks for downloading!
===============================================================
This DEMO FONT is for PERSONAL USE ONLY!
===============================================================

By installing or using this font, you are agree to the Product Usage Agreement:

1. This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You need a special license for PROMOTION or COMMERCIAL
3. CONTACT USE before any Promotional or Commercial Use!

EMAIL SUPPORT:
rismanginarwan8@gmail.com
support@garisman.com

===============================================================

OFFICIAL STORE:

 http://www.garisman.com

===============================================================

Paypal account for donation : https://paypal.me/rginarwan/

===============================================================

NOTE:
- If there is a problem, question, or anything about my fonts, please sent an email to: support@garisman.com
- Share your work with this font and tag us on instagram @grsmn.id #grsmnid

================
Best Regards,
Garisman Studio