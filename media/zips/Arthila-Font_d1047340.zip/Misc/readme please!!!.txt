Thank you for downloading my free font, in my love website DAFONT
please use it for your design needs, 
this type of license font is free personal use,
you can use it for personal non-commercial projects,
if you need this font in the full version please visit my online store:

at the link: www.thehungryjpeg.com/sheillatype
������������� www.creativemarket.com/sheillatype

lots of interesting promotions offered for my font in some font marketplaces.


Best Regards,

Thank You]
Moh. Taufiq